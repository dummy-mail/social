import React from 'react'

const FriendList = () => {
  return (
    <>
      
    </>
  )
}

export default FriendList